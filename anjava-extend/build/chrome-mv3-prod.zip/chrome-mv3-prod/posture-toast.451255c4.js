var e,t;"function"==typeof(e=globalThis.define)&&(t=e,e=null),function(t,o,n,a,s){var r="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},i="function"==typeof r[a]&&r[a],d=i.cache||{},l="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function c(e,o){if(!d[e]){if(!t[e]){var n="function"==typeof r[a]&&r[a];if(!o&&n)return n(e,!0);if(i)return i(e,!0);if(l&&"string"==typeof e)return l(e);var s=Error("Cannot find module '"+e+"'");throw s.code="MODULE_NOT_FOUND",s}p.resolve=function(o){var n=t[e][1][o];return null!=n?n:o},p.cache={};var u=d[e]=new c.Module(e);t[e][0].call(u.exports,p,u,u.exports,this)}return d[e].exports;function p(e){var t=p.resolve(e);return!1===t?{}:c(t)}}c.isParcelRequire=!0,c.Module=function(e){this.id=e,this.bundle=c,this.exports={}},c.modules=t,c.cache=d,c.parent=i,c.register=function(e,o){t[e]=[function(e,t){t.exports=o},{}]},Object.defineProperty(c,"root",{get:function(){return r[a]}}),r[a]=c;for(var u=0;u<o.length;u++)c(o[u]);if(n){var p=c(n);"object"==typeof exports&&"undefined"!=typeof module?module.exports=p:"function"==typeof e&&e.amd?e(function(){return p}):s&&(this[s]=p)}}({"1Jcsn":[function(e,t,o){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(o),n.export(o,"config",()=>a);let a={matches:["http://*/*","https://*/*"],run_at:"document_idle"},s="anjava-posture-toast",r="anjava-posture-style",i="__anjava_web_relay__",d="__anjava_toast_listener__",l=null,c={TURTLE_NECK:"\uac70\ubd81\ubaa9 \uc790\uc138\uac00 \uac10\uc9c0\ub410\uc5b4\uc694. \ubaa9\uc744 \ubc14\ub974\uac8c \uc138\uc6cc\uc8fc\uc138\uc694.",turtle_neck:"\uac70\ubd81\ubaa9 \uc790\uc138\uac00 \uac10\uc9c0\ub410\uc5b4\uc694. \ubaa9\uc744 \ubc14\ub974\uac8c \uc138\uc6cc\uc8fc\uc138\uc694.",SHOULDER_ISSUE:"\uc5b4\uae68 \uc790\uc138 \uc774\uc0c1\uc774 \uac10\uc9c0\ub410\uc5b4\uc694. \uc5b4\uae68\ub97c \ub4a4\ub85c \ud3b4\uc8fc\uc138\uc694.",ROUND_SHOULDER:"\ub77c\uc6b4\ub4dc\uc204\ub354\uac00 \uac10\uc9c0\ub410\uc5b4\uc694. \uc5b4\uae68\ub97c \ub4a4\ub85c \ud3b4\uc8fc\uc138\uc694.",round_shoulder:"\ub77c\uc6b4\ub4dc\uc204\ub354\uac00 \uac10\uc9c0\ub410\uc5b4\uc694. \uc5b4\uae68\ub97c \ub4a4\ub85c \ud3b4\uc8fc\uc138\uc694.",SHOULDER_ASYMMETRY:"\uc5b4\uae68 \ube44\ub300\uce6d\uc774 \uac10\uc9c0\ub410\uc5b4\uc694. \uc5b4\uae68 \ub192\uc774\ub97c \ub9de\ucdb0\uc8fc\uc138\uc694.",shoulder_tilted:"\uc5b4\uae68 \ube44\ub300\uce6d\uc774 \uac10\uc9c0\ub410\uc5b4\uc694. \uc5b4\uae68 \ub192\uc774\ub97c \ub9de\ucdb0\uc8fc\uc138\uc694.",DARK_ENV:"\uc5b4\ub450\uc6b4 \ud658\uacbd\uc774 \uac10\uc9c0\ub410\uc5b4\uc694. \uc8fc\ubcc0 \ubc1d\uae30\ub97c \ub192\uc5ec\uc8fc\uc138\uc694.",dark_env:"\uc5b4\ub450\uc6b4 \ud658\uacbd\uc774 \uac10\uc9c0\ub410\uc5b4\uc694. \uc8fc\ubcc0 \ubc1d\uae30\ub97c \ub192\uc5ec\uc8fc\uc138\uc694.",GOOD_POSTURE:"\uc790\uc138\uac00 \uad50\uc815\ub410\uc5b4\uc694. \ubc14\ub978 \uc790\uc138\ub97c \uc720\uc9c0\ud574\ubcf4\uc138\uc694."},u={TURTLE_NECK:"assets/turtleneck.png",ROUND_SHOULDER:"assets/round-shoulder.png",SHOULDER_ISSUE:"assets/round-shoulder.png",SHOULDER_ASYMMETRY:"assets/shoulder-notsame.png"},p={turtle_neck:"TURTLE_NECK",round_shoulder:"ROUND_SHOULDER",shoulder_issue:"SHOULDER_ISSUE",shoulder_tilted:"SHOULDER_ASYMMETRY",shoulder_asymmetry:"SHOULDER_ASYMMETRY"};function f(e){e.classList.add("is-out"),window.setTimeout(()=>e.remove(),240)}window[i]||(window[i]=!0,window.addEventListener("message",e=>{if(e.source===window){if(e.data?.type==="ANJAVA_POSTURE_RELAY"){let t="string"==typeof e.data.relayId?e.data.relayId:"";chrome.runtime.sendMessage({type:"POSTURE_ALERT_FROM_WEB",state:e.data.state,message:e.data.message,soundEnabled:e.data.soundEnabled,suppressSystemNotification:!0===e.data.suppressSystemNotification}).then(()=>{t&&window.postMessage({type:"ANJAVA_POSTURE_RELAY_ACK",relayId:t},"*")}).catch(()=>{});return}e.data?.type==="ANJAVA_WEB_SESSION_STATE"&&chrome.runtime.sendMessage({type:"SYNC_WEB_SESSION",state:e.data.state,sessionId:e.data.sessionId,startedAt:e.data.startedAt,pausedTotalMs:e.data.pausedTotalMs??0}).catch(()=>{})}})),window[d]&&chrome.runtime.onMessage.removeListener(window[d]);let m=e=>{if("TIMELINE_POSTED"===e.type){window.postMessage({type:"ANJAVA_TIMELINE_POSTED"},"*");return}if("SESSION_CHANGED"===e.type){window.postMessage({type:"ANJAVA_SESSION_CHANGED"},"*");return}if("POSTURE_ALERT"!==e.type)return;let t="GOOD_POSTURE"===e.state,o=e.state&&c[e.state]||e.message||"\uc790\uc138\ub97c \ud655\uc778\ud574\uc8fc\uc138\uc694.";!function(e,t,o,n){(function(){if(document.getElementById(r))return;let e=document.createElement("style");e.id=r,e.textContent=`
    #${s} {
      position: fixed;
      top: 24px;
      right: 24px;
      z-index: 2147483647;
      width: min(420px, calc(100vw - 32px));
      overflow: hidden;
      border: 1px solid rgba(191, 219, 254, 0.9);
      border-radius: 22px;
      background: linear-gradient(135deg, #ffffff 0%, #f8fbff 100%);
      color: #18181b;
      box-shadow: 0 22px 60px rgba(37, 99, 235, 0.18), 0 8px 22px rgba(15, 23, 42, 0.1);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Pretendard, sans-serif;
      pointer-events: auto;
      animation: anjava-toast-in 0.28s cubic-bezier(0.16, 1, 0.3, 1);
    }
    #${s}:before {
      content: "";
      position: absolute;
      inset: 0 0 auto 0;
      height: 4px;
      background: linear-gradient(90deg, #ef4444, #fb7185);
    }
    #${s}.is-good:before {
      background: linear-gradient(90deg, #2563eb, #22c55e);
    }
    #${s}.is-out {
      animation: anjava-toast-out 0.22s ease forwards;
    }
    #${s} .toast-main {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 16px 16px 14px;
    }
    #${s} .toast-icon {
      display: flex;
      width: 38px;
      height: 38px;
      flex-shrink: 0;
      align-items: center;
      justify-content: center;
      border-radius: 999px;
      background: #fef2f2;
      color: #dc2626;
      font-size: 18px;
      font-weight: 900;
      box-shadow: inset 0 0 0 1px rgba(248, 113, 113, 0.18);
    }
    #${s}.is-good .toast-icon {
      background: #eff6ff;
      color: #2563eb;
      box-shadow: inset 0 0 0 1px rgba(37, 99, 235, 0.16);
    }
    #${s} .toast-copy {
      min-width: 0;
      flex: 1;
    }
    #${s} .toast-kicker {
      margin-bottom: 2px;
      height: 18px;
    }
    #${s} .toast-logo {
      display: block;
      width: 64px;
      height: 18px;
      object-fit: contain;
      object-position: left center;
    }
    #${s} .toast-title {
      color: #111827;
      font-size: 14px;
      font-weight: 850;
      letter-spacing: -0.01em;
    }
    #${s} .toast-body {
      margin-top: 3px;
      color: #52525b;
      font-size: 13px;
      line-height: 1.55;
      word-break: keep-all;
    }
    #${s} .toast-avatar {
      width: 46px;
      height: 54px;
      flex-shrink: 0;
      overflow: hidden;
      border-radius: 16px;
    }
    #${s} .toast-avatar img {
      display: block;
      width: 100%;
      height: 100%;
      object-fit: contain;
      object-position: center bottom;
    }
    #${s} .toast-close {
      position: absolute;
      right: 10px;
      top: 10px;
      display: flex;
      width: 24px;
      height: 24px;
      align-items: center;
      justify-content: center;
      border: 0;
      border-radius: 999px;
      background: rgba(244, 244, 245, 0.9);
      color: #71717a;
      cursor: pointer;
      font-size: 14px;
      line-height: 1;
      padding: 0;
    }
    #${s} .toast-close:hover {
      background: #e4e4e7;
      color: #27272a;
    }
    #${s} .toast-progress {
      height: 4px;
      background: linear-gradient(90deg, #ef4444, #fb7185);
      transform-origin: left;
      animation: anjava-toast-progress 6s linear forwards;
    }
    #${s}.is-good .toast-progress {
      background: linear-gradient(90deg, #2563eb, #22c55e);
    }
    @keyframes anjava-toast-in {
      from { opacity: 0; transform: translateX(28px) scale(0.98); }
      to { opacity: 1; transform: translateX(0) scale(1); }
    }
    @keyframes anjava-toast-out {
      to { opacity: 0; transform: translateX(28px) scale(0.98); }
    }
    @keyframes anjava-toast-progress {
      from { transform: scaleX(1); }
      to { transform: scaleX(0); }
    }
  `,document.head.appendChild(e)})(),l&&(clearTimeout(l),l=null);let a=document.getElementById(s);a&&a.remove();let i=document.createElement("div");i.id=s,o&&i.classList.add("is-good");let d=document.createElement("div");d.className="toast-main";let c=document.createElement("div");c.className="toast-icon",c.textContent=o?"\u2713":"!";let m=document.createElement("div");m.className="toast-copy";let g=document.createElement("div");g.className="toast-kicker";let h=document.createElement("img");h.className="toast-logo",h.src=chrome.runtime.getURL("assets/logo.png"),h.alt="Anjava",g.append(h);let b=document.createElement("div");b.className="toast-title",b.textContent=o?"\uc88b\uc740 \uc790\uc138\ub97c \uc720\uc9c0\ud558\uace0 \uc788\uc5b4\uc694":"\uc790\uc138 \uad50\uc815 \uc54c\ub9bc";let E=document.createElement("div");E.className="toast-body",E.textContent=e;let x=document.createElement("div");x.className="toast-avatar",x.setAttribute("aria-hidden","true");let _=document.createElement("img");_.src=chrome.runtime.getURL(function(e){let t=e?p[e.toLowerCase()]??e.toUpperCase():"";return u[t]??"assets/avatar.png"}(t)),_.alt="",x.append(_);let y=document.createElement("button");y.className="toast-close",y.textContent="\xd7",y.setAttribute("aria-label","\ub2eb\uae30"),y.onclick=()=>f(i);let w=document.createElement("div");w.className="toast-progress",m.append(g,b,E),d.append(c,m,x,y),i.append(d,w),document.body.appendChild(i),function(e,t){if(t)try{let t=window.AudioContext||window.webkitAudioContext;if(!t)return;let o=new t,n=(e,t,n,a=.18)=>{let s=o.createOscillator(),r=o.createGain();s.type="sine",s.frequency.setValueAtTime(e,t),r.gain.setValueAtTime(1e-4,t),r.gain.exponentialRampToValueAtTime(a,t+.018),r.gain.exponentialRampToValueAtTime(1e-4,t+n),s.connect(r),r.connect(o.destination),s.start(t),s.stop(t+n+.02)},a=o.currentTime;e?(n(660,a,.16,.13),n(880,a+.14,.2,.12)):(n(1046.5,a,.17),n(1318.5,a+.14,.24)),window.setTimeout(()=>o.close().catch(()=>{}),650)}catch{}}(o,n),l=window.setTimeout(()=>f(i),6e3)}(o,e.state,t,!1!==e.soundEnabled)};window[d]=m,chrome.runtime.onMessage.addListener(m)},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],cHUbl:[function(e,t,o){o.interopDefault=function(e){return e&&e.__esModule?e:{default:e}},o.defineInteropFlag=function(e){Object.defineProperty(e,"__esModule",{value:!0})},o.exportAll=function(e,t){return Object.keys(e).forEach(function(o){"default"===o||"__esModule"===o||t.hasOwnProperty(o)||Object.defineProperty(t,o,{enumerable:!0,get:function(){return e[o]}})}),t},o.export=function(e,t,o){Object.defineProperty(e,t,{enumerable:!0,get:o})}},{}]},["1Jcsn"],"1Jcsn","parcelRequire4351"),globalThis.define=t;